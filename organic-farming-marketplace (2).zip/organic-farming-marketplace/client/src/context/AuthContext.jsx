import { createContext, useContext, useEffect, useState } from "react";
import api from "../api";

const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ofm_user") || "null"); } catch { return null; }
  });
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const token = localStorage.getItem("ofm_token");
    if (!token) { setLoading(false); return; }
    api.get("/auth/me").then(({ data }) => {
      setUser(data.user); localStorage.setItem("ofm_user", JSON.stringify(data.user));
    }).catch(() => {
      localStorage.removeItem("ofm_token"); localStorage.removeItem("ofm_user"); setUser(null);
    }).finally(() => setLoading(false));
  }, []);
  const signIn = data => {
    localStorage.setItem("ofm_token", data.token);
    localStorage.setItem("ofm_user", JSON.stringify(data.user));
    setUser(data.user);
  };
  const signOut = () => {
    localStorage.removeItem("ofm_token"); localStorage.removeItem("ofm_user"); setUser(null);
  };
  return <AuthContext.Provider value={{ user, loading, signIn, signOut }}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
