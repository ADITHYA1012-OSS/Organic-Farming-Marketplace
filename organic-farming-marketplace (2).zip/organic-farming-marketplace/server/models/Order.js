import mongoose from "mongoose";

const orderItemSchema = new mongoose.Schema({
  product: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
  productName: { type: String, required: true },
  farmer: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  quantity: { type: Number, required: true, min: 1 },
  unit: { type: String, required: true },
  price: { type: Number, required: true, min: 0 }
}, { _id: false });

const orderSchema = new mongoose.Schema({
  customer: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  items: { type: [orderItemSchema], validate: v => v.length > 0 },
  totalAmount: { type: Number, required: true, min: 0 },
  deliveryAddress: { type: String, required: true, trim: true, maxlength: 300 },
  status: { type: String, enum: ["Placed", "Confirmed", "Packed", "Delivered", "Cancelled"], default: "Placed" }
}, { timestamps: true });

export default mongoose.model("Order", orderSchema);
