# Organic Farming Marketplace (MERN)

A beginner-friendly marketplace for organic produce. Farmers can manage their own products, customers can browse products and place basic orders, and admins can manage users/products. No payment gateway is included.

## Features
- Register/login with JWT; roles: `customer`, `farmer`, `admin`
- Product CRUD (farmers can manage only their own products)
- Search/filter product catalog
- Basic cart in the React UI
- Place orders and view order history
- Farmer order list and status updates
- Admin product/user overview
- MongoDB with Mongoose validation

## Requirements
- Node.js 18+ (20+ recommended)
- MongoDB Community Server running locally, or a MongoDB Atlas connection string
- npm

## 1. Configure backend
Open a terminal in `server/`:
```bash
npm install
```
Copy `.env.example` to `.env` and update `MONGO_URI` and `JWT_SECRET`.
On Windows PowerShell:
```powershell
Copy-Item .env.example .env
```
On macOS/Linux:
```bash
cp .env.example .env
```
Start the API:
```bash
npm run dev
```
The API runs at `http://localhost:5000`. Check `http://localhost:5000/api/health`.

## 2. Configure frontend
Open a second terminal in `client/`:
```bash
npm install
```
Copy `.env.example` to `.env` if you need to change the API URL. Start React:
```bash
npm run dev
```
Open the URL printed by Vite, usually `http://localhost:5173`.

## 3. Create the first admin
Register a normal account through the UI. Then, while the backend is stopped, edit that user's role in MongoDB to `admin`, or use MongoDB Compass:
- Database: `organic_farming_marketplace`
- Collection: `users`
- Change that user's `role` to `"admin"`
Restart the backend and sign in again. Do not expose a public admin-registration option.

## 4. Use the app
1. Register a customer account to browse and place orders.
2. Register another account and choose the **Farmer** role to add products.
3. Add products as the farmer, then sign in as a customer to order them.
4. Farmers can review orders containing their products and update their status.
5. Admin users can view the admin panel.

## API overview
- `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`
- `GET /api/products`, `GET /api/products/:id`
- `POST /api/products`, `PUT /api/products/:id`, `DELETE /api/products/:id`
- `GET /api/farmers`
- `POST /api/orders`, `GET /api/orders/my-orders`
- `GET /api/orders/farmer-orders`, `PATCH /api/orders/:id/status`
- `GET /api/admin/summary`, `GET /api/admin/users`

## Notes
- This is an educational starter project, not a production-ready commerce system.
- Orders use a basic order-placement flow only; no online payment is collected.
- Product image fields accept image URLs. File uploads are not configured.
- For production, add rate limiting, email verification, password reset, audit logs, stronger deployment secrets, tests, and a reviewed checkout/stock-reservation strategy.
- Never commit `.env` or share your JWT secret.
