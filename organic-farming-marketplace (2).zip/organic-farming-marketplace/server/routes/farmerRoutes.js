import { Router } from "express";
import User from "../models/User.js";
const router = Router();
router.get("/", async (_req, res, next) => {
  try {
    const farmers = await User.find({ role: "farmer" }).select("name location createdAt").sort({ name: 1 });
    res.json({ farmers });
  } catch (err) { next(err); }
});
export default router;
