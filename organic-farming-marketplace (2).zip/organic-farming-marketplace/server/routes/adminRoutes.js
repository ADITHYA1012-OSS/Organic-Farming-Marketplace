import { Router } from "express";
import User from "../models/User.js";
import Product from "../models/Product.js";
import Order from "../models/Order.js";
import { protect, allowRoles } from "../middleware/authMiddleware.js";

const router = Router();
router.use(protect, allowRoles("admin"));
router.get("/summary", async (_req, res, next) => {
  try {
    const [users, farmers, products, orders] = await Promise.all([
      User.countDocuments(), User.countDocuments({ role: "farmer" }),
      Product.countDocuments(), Order.countDocuments()
    ]);
    res.json({ users, farmers, products, orders });
  } catch (err) { next(err); }
});
router.get("/users", async (_req, res, next) => {
  try {
    const users = await User.find().select("name email role location createdAt").sort({ createdAt: -1 });
    res.json({ users });
  } catch (err) { next(err); }
});
export default router;
