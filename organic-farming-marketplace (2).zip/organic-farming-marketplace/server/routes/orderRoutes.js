import { Router } from "express";
import mongoose from "mongoose";
import Product from "../models/Product.js";
import Order from "../models/Order.js";
import { protect, allowRoles } from "../middleware/authMiddleware.js";

const router = Router();
router.post("/", protect, allowRoles("customer", "admin"), async (req, res, next) => {
  try {
    const { items, deliveryAddress } = req.body;
    if (!Array.isArray(items) || items.length === 0) return res.status(400).json({ message: "Your cart is empty." });
    if (!deliveryAddress?.trim()) return res.status(400).json({ message: "Delivery address is required." });
    // Atomic conditional stock decrements reduce the chance of overselling.
    const normalized = new Map();
    for (const item of items) {
      if (!mongoose.isValidObjectId(item.product) || !Number.isInteger(Number(item.quantity)) || Number(item.quantity) < 1) {
        return res.status(400).json({ message: "Cart contains an invalid item." });
      }
      const key = String(item.product);
      normalized.set(key, (normalized.get(key) || 0) + Number(item.quantity));
    }
    const orderItems = [];
    let totalAmount = 0;
    const decremented = [];
    for (const [productId, quantity] of normalized.entries()) {
      const product = await Product.findOneAndUpdate(
        { _id: productId, quantity: { $gte: quantity } },
        { $inc: { quantity: -quantity } },
        { new: true }
      );
      if (!product) {
        for (const change of decremented) await Product.updateOne({ _id: change.id }, { $inc: { quantity: change.quantity } });
        return res.status(409).json({ message: "A product is unavailable or does not have enough stock. Refresh the catalog and try again." });
      }
      decremented.push({ id: product._id, quantity });
      const line = { product: product._id, productName: product.name, farmer: product.farmer, quantity, unit: product.unit, price: product.price };
      orderItems.push(line);
      totalAmount += product.price * quantity;
    }
    try {
      const order = await Order.create({ customer: req.user._id, items: orderItems, totalAmount, deliveryAddress: deliveryAddress.trim() });
      res.status(201).json({ order });
    } catch (err) {
      for (const change of decremented) await Product.updateOne({ _id: change.id }, { $inc: { quantity: change.quantity } });
      throw err;
    }
  } catch (err) { next(err); }
});
router.get("/my-orders", protect, async (req, res, next) => {
  try {
    const orders = await Order.find({ customer: req.user._id }).populate("customer", "name email").sort({ createdAt: -1 });
    res.json({ orders });
  } catch (err) { next(err); }
});
router.get("/farmer-orders", protect, allowRoles("farmer", "admin"), async (req, res, next) => {
  try {
    const filter = req.user.role === "admin" ? {} : { "items.farmer": req.user._id };
    const orders = await Order.find(filter).populate("customer", "name email phone").sort({ createdAt: -1 });
    res.json({ orders });
  } catch (err) { next(err); }
});
router.patch("/:id/status", protect, allowRoles("farmer", "admin"), async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid order ID." });
    const allowed = ["Confirmed", "Packed", "Delivered", "Cancelled"];
    if (!allowed.includes(req.body.status)) return res.status(400).json({ message: "Invalid order status." });
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: "Order not found." });
    if (req.user.role !== "admin" && !order.items.some(item => String(item.farmer) === String(req.user._id))) {
      return res.status(403).json({ message: "This order does not contain your products." });
    }
    if (order.status === "Cancelled" || order.status === "Delivered") return res.status(400).json({ message: "This order is already closed." });
    if (req.body.status === "Cancelled" && order.status !== "Placed") return res.status(400).json({ message: "Only newly placed orders can be cancelled." });
    order.status = req.body.status;
    await order.save();
    res.json({ order });
  } catch (err) { next(err); }
});
export default router;
