import { Link, NavLink, useNavigate } from "react-router-dom";
import { Sprout, ShoppingBasket, UserRound, LogOut, LayoutDashboard } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function Layout({ children, cartCount = 0 }) {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const logout = () => { signOut(); navigate("/"); };
  return <div className="app-shell">
    <header className="topbar">
      <Link className="brand" to="/"><span className="brand-mark"><Sprout size={23}/></span><span>root<span className="brand-amp">&</span>harvest<small>ORGANIC MARKETPLACE</small></span></Link>
      <nav className="nav-links">
        <NavLink to="/" end>Home</NavLink><NavLink to="/products">Shop</NavLink><NavLink to="/farmers">Farmers</NavLink>
        {user && <NavLink to="/orders">My orders</NavLink>}
        {user?.role === "farmer" && <NavLink to="/dashboard"><LayoutDashboard size={16}/> Farmer</NavLink>}
        {user?.role === "admin" && <NavLink to="/admin"><LayoutDashboard size={16}/> Admin</NavLink>}
      </nav>
      <div className="nav-actions">
        <Link to="/cart" className="icon-link" aria-label="Shopping cart"><ShoppingBasket size={19}/><span>Cart</span>{cartCount > 0 && <b className="cart-count">{cartCount}</b>}</Link>
        {user ? <><span className="user-chip"><UserRound size={16}/>{user.name.split(" ")[0]}</span><button className="button button-outline button-small" onClick={logout}><LogOut size={15}/> Log out</button></> : <Link to="/login" className="button button-primary button-small">Sign in</Link>}
      </div>
    </header>
    <main>{children}</main>
    <footer className="footer"><Link className="footer-brand" to="/"><Sprout size={20}/> root&harvest</Link><span>Good food. Good soil. A better tomorrow.</span><span>© {new Date().getFullYear()} Root & Harvest</span></footer>
  </div>;
}
