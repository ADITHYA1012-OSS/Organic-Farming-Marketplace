import { Link } from "react-router-dom";
import { ShoppingBasket, Leaf, MapPin } from "lucide-react";

const fallback = "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=900&q=80";
export default function ProductCard({ product, onAdd }) {
  const farmer = product.farmer;
  return <article className="product-card">
    <Link to={`/products/${product._id}`} className="product-image-wrap">
      <img src={product.image || fallback} alt={product.name} className="product-image" onError={e => { e.currentTarget.src = fallback; }}/>
      <span className="organic-tag"><Leaf size={12}/> Organic</span>
    </Link>
    <div className="product-info">
      <span className="eyebrow">{product.category}</span>
      <Link to={`/products/${product._id}`} className="product-title">{product.name}</Link>
      <div className="farmer-line"><MapPin size={13}/>{farmer?.name || "Local farmer"}{farmer?.location ? ` · ${farmer.location}` : ""}</div>
      <div className="product-bottom"><div><strong>₹{Number(product.price).toFixed(2)}</strong><span className="unit"> / {product.unit}</span><small>{product.quantity > 0 ? `${product.quantity} ${product.unit} available` : "Out of stock"}</small></div>
      <button className="add-button" disabled={product.quantity <= 0} onClick={() => onAdd(product)} aria-label={`Add ${product.name} to cart`}><ShoppingBasket size={17}/></button></div>
    </div>
  </article>;
}
