import mongoose from "mongoose";

const productSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  description: { type: String, trim: true, maxlength: 1000, default: "" },
  category: { type: String, required: true, trim: true, maxlength: 60 },
  price: { type: Number, required: true, min: 0 },
  quantity: { type: Number, required: true, min: 0 },
  unit: { type: String, enum: ["kg", "g", "piece", "bunch", "litre", "pack"], default: "kg" },
  isOrganic: { type: Boolean, default: true },
  image: { type: String, trim: true, default: "" },
  farmer: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
}, { timestamps: true });

productSchema.index({ name: "text", description: "text", category: "text" });
export default mongoose.model("Product", productSchema);
