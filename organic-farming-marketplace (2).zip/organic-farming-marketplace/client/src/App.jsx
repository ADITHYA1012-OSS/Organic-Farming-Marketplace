import { useEffect, useMemo, useState } from "react";
import { Routes, Route, Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { ArrowRight, ArrowUpRight, CheckCircle2, Leaf, Search, Sprout, Truck, ShieldCheck, Heart, Plus, Pencil, Trash2, PackageCheck, Users, ShoppingBasket } from "lucide-react";
import api from "./api";
import { useAuth } from "./context/AuthContext";
import Layout from "./components/Layout";
import ProductCard from "./components/ProductCard";
import ProtectedRoute from "./components/ProtectedRoute";

const money = n => `₹${Number(n || 0).toFixed(2)}`;
const fallbackImage = "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=900&q=80";
function ErrorMessage({ children }) { return children ? <div className="alert alert-error">{children}</div> : null; }
function SuccessMessage({ children }) { return children ? <div className="alert alert-success"><CheckCircle2 size={17}/>{children}</div> : null; }
function useCart() {
  const [cart, setCart] = useState(() => {
    try { return JSON.parse(localStorage.getItem("ofm_cart") || "[]"); } catch { return []; }
  });
  useEffect(() => localStorage.setItem("ofm_cart", JSON.stringify(cart)), [cart]);
  const add = product => setCart(old => {
    const found = old.find(x => x.product._id === product._id);
    if (found) return old.map(x => x.product._id === product._id ? { ...x, quantity: Math.min(x.quantity + 1, product.quantity) } : x);
    return [...old, { product, quantity: 1 }];
  });
  const setQuantity = (id, quantity) => setCart(old => old.map(x => x.product._id === id ? { ...x, quantity: Math.max(1, Math.min(Number(quantity) || 1, x.product.quantity)) } : x));
  const remove = id => setCart(old => old.filter(x => x.product._id !== id));
  return { cart, add, setQuantity, remove, clear: () => setCart([]), count: cart.reduce((sum, x) => sum + x.quantity, 0) };
}

function Home({ add }) {
  const [products, setProducts] = useState([]);
  useEffect(() => { api.get("/products").then(r => setProducts(r.data.products.slice(0, 4))).catch(() => {}); }, []);
  return <>
    <section className="hero">
      <div className="hero-copy"><div className="pill"><span className="pulse-dot"/> FRESH FROM THE FARM</div>
        <h1>Real food.<br/><em>Rooted in good.</em></h1>
        <p>Meet the farmers behind your food. Shop seasonal, organic goodness grown with care and delivered from local fields to your table.</p>
        <div className="hero-actions"><Link to="/products" className="button button-light">Explore the harvest <ArrowRight size={17}/></Link><Link to="/farmers" className="text-link text-link-light">Meet our farmers <ArrowUpRight size={16}/></Link></div>
        <div className="hero-trust"><span><Leaf size={16}/> Farm-grown</span><span><ShieldCheck size={16}/> Farmer-direct</span><span><Heart size={16}/> Thoughtfully grown</span></div>
      </div>
      <div className="hero-visual"><img src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=85" alt="Sunlight over a lush green farm"/><div className="hero-note"><span className="note-icon"><Sprout size={21}/></span><div><strong>Grown with purpose</strong><small>Better for the soil, better for you.</small></div></div><span className="hero-stamp">GOOD<br/>GROWS<br/>HERE <Leaf size={22}/></span></div>
      <div className="hero-grain">01 / THE GOOD FOOD MOVEMENT</div>
    </section>
    <section className="benefits"><div><span className="benefit-icon"><Sprout/></span><div><strong>Know your grower</strong><p>Real farmers, real stories.</p></div></div><div><span className="benefit-icon"><Leaf/></span><div><strong>Seasonal goodness</strong><p>Harvested with care.</p></div></div><div><span className="benefit-icon"><Truck/></span><div><strong>Direct from farms</strong><p>Less distance, more freshness.</p></div></div></section>
    <section className="section-block"><div className="section-heading"><div><span className="eyebrow">THE MARKET STAND</span><h2>Fresh picks, <em>this week.</em></h2><p>Good things are growing. Take a look at what's in season.</p></div><Link to="/products" className="text-link">Shop all produce <ArrowRight size={16}/></Link></div>
      {products.length ? <div className="product-grid">{products.map(p => <ProductCard key={p._id} product={p} onAdd={add}/>)}</div> : <div className="empty-state"><Sprout size={30}/><h3>Your next favourite is growing here.</h3><p>Browse the marketplace to see what local farmers have listed.</p><Link to="/products" className="button button-primary">Explore products</Link></div>}
    </section>
    <section className="farmer-banner"><div><span className="eyebrow">GROW SOMETHING GOOD</span><h2>Are you a farmer?</h2><p>Bring your harvest to more homes. Create a farmer account and list your produce in minutes.</p><Link to="/register" className="button button-light">Join the marketplace <ArrowRight size={16}/></Link></div><img src="https://images.unsplash.com/photo-1592982537447-6f2a6a0a1f4b?auto=format&fit=crop&w=1000&q=80" alt="Freshly harvested vegetables"/></section>
  </>;
}

function Products({ add }) {
  const [products, setProducts] = useState([]);
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState(searchParams.get("search") || "");
  const [category, setCategory] = useState(searchParams.get("category") || "All");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const load = async () => {
    setLoading(true); setError("");
    try {
      const params = {};
      if (search.trim()) params.search = search.trim();
      if (category !== "All") params.category = category;
      const { data } = await api.get("/products", { params }); setProducts(data.products);
      setSearchParams(Object.fromEntries(Object.entries({ search: search.trim(), category: category !== "All" ? category : "" }).filter(([,v]) => v)));
    } catch (e) { setError(e.response?.data?.message || "Could not load products. Check that the backend is running."); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);
  const categories = ["All", "Vegetables", "Fruits", "Grains", "Dairy", "Herbs", "Other"];
  return <div className="page-wrap"><div className="page-intro"><span className="eyebrow">THE FARMERS' MARKET</span><h1>Good things, <em>grown well.</em></h1><p>Discover organic produce from farmers who care about the land.</p></div>
    <form className="filter-bar" onSubmit={e => { e.preventDefault(); load(); }}><div className="search-box"><Search size={18}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search vegetables, fruits, grains…"/></div><select value={category} onChange={e => { setCategory(e.target.value); setTimeout(() => {}, 0); }} aria-label="Filter category">{categories.map(c => <option key={c}>{c}</option>)}</select><button className="button button-primary" type="submit">Find produce</button></form>
    <ErrorMessage>{error}</ErrorMessage>
    {loading ? <p className="loading-text">Gathering the harvest…</p> : products.length ? <div className="product-grid">{products.map(p => <ProductCard key={p._id} product={p} onAdd={add}/>)}</div> : <div className="empty-state"><Search size={30}/><h3>No produce found just yet.</h3><p>Try another search or category.</p><button className="button button-outline" onClick={() => { setSearch(""); setCategory("All"); setTimeout(load, 0); }}>Clear filters</button></div>}
  </div>;
}

function ProductDetail({ add }) {
  const { id } = useParams(); const [product, setProduct] = useState(null); const [error, setError] = useState("");
  useEffect(() => { api.get(`/products/${id}`).then(r => setProduct(r.data.product)).catch(e => setError(e.response?.data?.message || "Product not found.")); }, [id]);
  if (error) return <div className="page-wrap"><ErrorMessage>{error}</ErrorMessage><Link to="/products">Back to shop</Link></div>;
  if (!product) return <div className="page-wrap">Loading product…</div>;
  return <div className="page-wrap detail-layout"><img className="detail-image" src={product.image || fallbackImage} onError={e => e.currentTarget.src = fallbackImage} alt={product.name}/><div className="detail-copy"><span className="eyebrow">{product.category} · ORGANIC</span><h1>{product.name}</h1><p>{product.description || "Freshly grown with care by a local farmer."}</p><div className="detail-price">{money(product.price)} <span>/ {product.unit}</span></div><p className="muted">{product.quantity} {product.unit} currently available</p><p><strong>Grown by:</strong> {product.farmer?.name || "Local farmer"} {product.farmer?.location ? `· ${product.farmer.location}` : ""}</p><button className="button button-primary" disabled={product.quantity < 1} onClick={() => add(product)}><ShoppingBasket size={17}/> Add to cart</button></div></div>;
}

function Farmers() {
  const [farmers, setFarmers] = useState([]); const [error, setError] = useState("");
  useEffect(() => { api.get("/farmers").then(r => setFarmers(r.data.farmers)).catch(e => setError(e.response?.data?.message || "Could not load farmers.")); }, []);
  return <div className="page-wrap"><div className="page-intro"><span className="eyebrow">PEOPLE BEHIND THE PRODUCE</span><h1>Meet your <em>farmers.</em></h1><p>Every good harvest starts with people who care.</p></div><ErrorMessage>{error}</ErrorMessage>
    {farmers.length ? <div className="farmer-grid">{farmers.map(f => <article className="farmer-card" key={f._id}><div className="farmer-avatar"><Sprout size={30}/></div><span className="eyebrow">LOCAL GROWER</span><h3>{f.name}</h3><p>{f.location || "Growing good things near you"}</p><span className="verified"><CheckCircle2 size={14}/> Marketplace farmer</span></article>)}</div> : <div className="empty-state"><Sprout size={30}/><h3>Our grower community is taking root.</h3><p>Farmer profiles appear here after farmers register.</p><Link to="/register" className="button button-primary">Join as a farmer</Link></div>}
  </div>;
}

function AuthPage({ mode }) {
  const { signIn } = useAuth(); const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "customer", phone: "", location: "" });
  const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  const change = e => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = async e => {
    e.preventDefault(); setError(""); setBusy(true);
    try {
      const { data } = await api.post(`/auth/${mode}`, form); signIn(data);
      navigate(data.user.role === "farmer" ? "/dashboard" : data.user.role === "admin" ? "/admin" : "/products");
    } catch (e) { setError(e.response?.data?.message || "Could not connect. Is the backend running?"); }
    finally { setBusy(false); }
  };
  return <div className="auth-wrap"><div className="auth-side"><div className="auth-quote"><Sprout size={30}/><h2>Good food starts with good roots.</h2><p>Support thoughtful farming, one harvest at a time.</p></div><img src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1100&q=85" alt="Green farmland"/></div>
    <div className="auth-panel"><Link to="/" className="back-link">← Back to home</Link><span className="eyebrow">{mode === "login" ? "WELCOME BACK" : "COME GROW WITH US"}</span><h1>{mode === "login" ? "Good to see you." : "Find your roots."}</h1><p>{mode === "login" ? "Sign in to continue to your marketplace." : "Create an account to get started."}</p>
      <ErrorMessage>{error}</ErrorMessage><form className="form-stack" onSubmit={submit}>
        {mode === "register" && <><label>Full name<input name="name" value={form.name} onChange={change} required maxLength="80" placeholder="Your name"/></label><label>I want to join as<select name="role" value={form.role} onChange={change}><option value="customer">Customer</option><option value="farmer">Farmer / grower</option></select></label><label>Location (optional)<input name="location" value={form.location} onChange={change} placeholder="City or village"/></label><label>Phone (optional)<input name="phone" value={form.phone} onChange={change} placeholder="Contact number"/></label></>}
        <label>Email address<input type="email" name="email" value={form.email} onChange={change} required placeholder="you@example.com" autoComplete="email"/></label><label>Password<input type="password" name="password" value={form.password} onChange={change} required minLength="8" placeholder="At least 8 characters" autoComplete={mode === "login" ? "current-password" : "new-password"}/></label>
        <button className="button button-primary button-wide" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"} <ArrowRight size={17}/></button>
      </form><p className="auth-switch">{mode === "login" ? "New to the marketplace?" : "Already have an account?"} <Link to={mode === "login" ? "/register" : "/login"}>{mode === "login" ? "Create account" : "Sign in"}</Link></p><p className="auth-note"><ShieldCheck size={14}/> Your account details are protected.</p>
    </div></div>;
}

function Cart({ cart, setQuantity, remove, clear }) {
  const { user } = useAuth(); const navigate = useNavigate();
  const [address, setAddress] = useState(user?.location || ""); const [error, setError] = useState(""); const [success, setSuccess] = useState(""); const [busy, setBusy] = useState(false);
  const total = cart.reduce((sum, x) => sum + Number(x.product.price) * x.quantity, 0);
  const checkout = async e => {
    e.preventDefault(); setError(""); setSuccess(""); if (!user) { navigate("/login", { state: { from: "/cart" } }); return; }
    setBusy(true);
    try {
      const { data } = await api.post("/orders", { deliveryAddress: address, items: cart.map(x => ({ product: x.product._id, quantity: x.quantity })) });
      clear(); setSuccess(`Order placed successfully! Order ID: ${data.order._id}`); 
    } catch (e) { setError(e.response?.data?.message || "Could not place order."); }
    finally { setBusy(false); }
  };
  return <div className="page-wrap"><div className="page-intro compact"><span className="eyebrow">YOUR BASKET</span><h1>A basket of <em>goodness.</em></h1></div><ErrorMessage>{error}</ErrorMessage><SuccessMessage>{success}</SuccessMessage>
    {!cart.length ? <div className="empty-state"><ShoppingBasket size={34}/><h3>Your basket is ready for something good.</h3><p>Find fresh, thoughtful produce from local farmers.</p><Link to="/products" className="button button-primary">Browse the market</Link></div> : <div className="cart-layout"><div className="cart-items">{cart.map(({ product, quantity }) => <article className="cart-item" key={product._id}><img src={product.image || fallbackImage} alt={product.name} onError={e => e.currentTarget.src = fallbackImage}/><div className="cart-item-info"><span className="eyebrow">{product.category}</span><h3>{product.name}</h3><p>{money(product.price)} / {product.unit}</p><div className="quantity-controls"><button onClick={() => quantity > 1 && setQuantity(product._id, quantity - 1)} aria-label="Decrease quantity">−</button><span>{quantity}</span><button disabled={quantity >= product.quantity} onClick={() => setQuantity(product._id, quantity + 1)} aria-label="Increase quantity">+</button><button className="remove-button" onClick={() => remove(product._id)}>Remove</button></div></div><strong>{money(product.price * quantity)}</strong></article>)}</div>
      <aside className="summary-card"><h2>Order summary</h2><div className="summary-row"><span>Items ({cart.reduce((s,x) => s+x.quantity,0)})</span><strong>{money(total)}</strong></div><div className="summary-row"><span>Delivery</span><strong>Confirmed by farmer</strong></div><div className="summary-total"><span>Total</span><strong>{money(total)}</strong></div><p className="summary-note">No online payment. This places an order request with the farmer.</p><form onSubmit={checkout} className="form-stack"><label>Delivery address<textarea value={address} onChange={e => setAddress(e.target.value)} required maxLength="300" rows="3" placeholder="House / street, city, PIN code"/></label><button className="button button-primary button-wide" disabled={busy}>{busy ? "Placing order…" : user ? "Place order" : "Sign in to order"} <ArrowRight size={16}/></button></form></aside></div>}
  </div>;
}

function Orders() {
  const [orders, setOrders] = useState([]); const [error, setError] = useState("");
  useEffect(() => { api.get("/orders/my-orders").then(r => setOrders(r.data.orders)).catch(e => setError(e.response?.data?.message || "Could not load orders.")); }, []);
  return <div className="page-wrap"><div className="page-intro compact"><span className="eyebrow">YOUR PURCHASES</span><h1>Order <em>history.</em></h1></div><ErrorMessage>{error}</ErrorMessage>
    {!orders.length && !error ? <div className="empty-state"><PackageCheck size={30}/><h3>No orders yet.</h3><p>Your order history will appear here.</p><Link to="/products" className="button button-primary">Shop the harvest</Link></div> : <div className="orders-list">{orders.map(o => <article className="order-card" key={o._id}><div className="order-top"><div><span className="eyebrow">ORDER #{o._id.slice(-8).toUpperCase()}</span><h3>{new Date(o.createdAt).toLocaleDateString()}</h3></div><span className={`status status-${o.status.toLowerCase()}`}>{o.status}</span></div><div className="order-lines">{o.items.map((it,i) => <div key={i}><span>{it.productName} × {it.quantity} {it.unit}</span><strong>{money(it.price * it.quantity)}</strong></div>)}</div><div className="order-total"><span>Delivery: {o.deliveryAddress}</span><strong>Total {money(o.totalAmount)}</strong></div></article>)}</div>}
  </div>;
}

function FarmerDashboard() {
  const { user } = useAuth(); const [products, setProducts] = useState([]); const [orders, setOrders] = useState([]);
  const [error, setError] = useState(""); const [notice, setNotice] = useState(""); const [editing, setEditing] = useState(null);
  const blank = { name:"", description:"", category:"Vegetables", price:"", quantity:"", unit:"kg", image:"", isOrganic:true };
  const [form, setForm] = useState(blank);
  const load = async () => {
    try {
      const [p,o] = await Promise.all([api.get("/products", { params: { farmer: user.id || user._id } }), api.get("/orders/farmer-orders")]);
      setProducts(p.data.products); setOrders(o.data.orders);
    } catch (e) { setError(e.response?.data?.message || "Could not load dashboard."); }
  };
  useEffect(() => { load(); }, []);
  const submit = async e => {
    e.preventDefault(); setError(""); setNotice("");
    try {
      if (editing) await api.put(`/products/${editing}`, form); else await api.post("/products", form);
      setNotice(editing ? "Product updated." : "Product added to the marketplace."); setForm(blank); setEditing(null); load();
    } catch (e) { setError(e.response?.data?.message || "Could not save product."); }
  };
  const edit = p => { setEditing(p._id); setForm({ name:p.name, description:p.description || "", category:p.category, price:p.price, quantity:p.quantity, unit:p.unit, image:p.image || "", isOrganic:p.isOrganic }); window.scrollTo({ top:0, behavior:"smooth" }); };
  const del = async id => { if (!window.confirm("Delete this product?")) return; try { await api.delete(`/products/${id}`); setNotice("Product deleted."); load(); } catch(e) { setError(e.response?.data?.message || "Could not delete product."); } };
  const updateStatus = async (id,status) => { try { await api.patch(`/orders/${id}/status`, {status}); setNotice(`Order marked ${status.toLowerCase()}.`); load(); } catch(e) { setError(e.response?.data?.message || "Could not update order."); } };
  return <div className="page-wrap"><div className="dashboard-heading"><div><span className="eyebrow">FARMER STUDIO</span><h1>Your harvest, <em>your shop.</em></h1><p>Welcome back, {user.name}. Keep your listings fresh and up to date.</p></div><span className="dashboard-badge"><Sprout size={18}/> Farmer account</span></div>
    <ErrorMessage>{error}</ErrorMessage><SuccessMessage>{notice}</SuccessMessage>
    <div className="dashboard-columns"><section className="panel"><div className="panel-heading"><div><span className="eyebrow">{editing ? "UPDATE LISTING" : "NEW LISTING"}</span><h2>{editing ? "Edit your produce" : "Add a product"}</h2></div><span className="panel-icon"><Plus/></span></div>
      <form className="form-stack" onSubmit={submit}><label>Product name<input required maxLength="120" value={form.name} onChange={e => setForm({...form,name:e.target.value})} placeholder="e.g. Fresh spinach"/></label><label>Category<select value={form.category} onChange={e => setForm({...form,category:e.target.value})}>{["Vegetables","Fruits","Grains","Dairy","Herbs","Other"].map(c => <option key={c}>{c}</option>)}</select></label><div className="form-row"><label>Price (₹)<input required type="number" min="0" step="0.01" value={form.price} onChange={e => setForm({...form,price:e.target.value})} placeholder="0.00"/></label><label>Quantity<input required type="number" min="0" step="1" value={form.quantity} onChange={e => setForm({...form,quantity:e.target.value})} placeholder="0"/></label></div><label>Unit<select value={form.unit} onChange={e => setForm({...form,unit:e.target.value})}>{["kg","g","piece","bunch","litre","pack"].map(u => <option key={u}>{u}</option>)}</select></label><label>Description<textarea rows="3" maxLength="1000" value={form.description} onChange={e => setForm({...form,description:e.target.value})} placeholder="Tell customers what makes it special…"/></label><label>Image URL (optional)<input type="url" value={form.image} onChange={e => setForm({...form,image:e.target.value})} placeholder="https://example.com/produce.jpg"/></label><label className="checkbox-label"><input type="checkbox" checked={form.isOrganic} onChange={e => setForm({...form,isOrganic:e.target.checked})}/> Mark as organically grown</label><button className="button button-primary button-wide">{editing ? "Save changes" : "Publish product"} <ArrowRight size={16}/></button>{editing && <button type="button" className="button button-outline button-wide" onClick={() => {setEditing(null);setForm(blank);}}>Cancel edit</button>}</form>
    </section><section className="panel listings-panel"><div className="panel-heading"><div><span className="eyebrow">YOUR INVENTORY</span><h2>Listed produce <span className="count-pill">{products.length}</span></h2></div></div>
      {!products.length ? <div className="mini-empty"><Sprout size={27}/><p>Your listings will show here once you publish your first product.</p></div> : <div className="listing-list">{products.map(p => <article className="listing-row" key={p._id}><img src={p.image || fallbackImage} alt={p.name} onError={e => e.currentTarget.src=fallbackImage}/><div className="listing-info"><strong>{p.name}</strong><small>{money(p.price)} / {p.unit} · {p.quantity} available</small></div><button className="mini-icon" onClick={() => edit(p)} aria-label={`Edit ${p.name}`}><Pencil size={16}/></button><button className="mini-icon danger" onClick={() => del(p._id)} aria-label={`Delete ${p.name}`}><Trash2 size={16}/></button></article>)}</div>}
    </section></div>
    <section className="panel orders-panel"><div className="panel-heading"><div><span className="eyebrow">CUSTOMER ACTIVITY</span><h2>Orders for your produce</h2></div></div>
      {!orders.length ? <div className="mini-empty"><PackageCheck size={27}/><p>Customer orders containing your produce will appear here.</p></div> : <div className="orders-list">{orders.map(o => <article className="order-card" key={o._id}><div className="order-top"><div><span className="eyebrow">ORDER #{o._id.slice(-8).toUpperCase()}</span><h3>{o.customer?.name || "Customer"} · {new Date(o.createdAt).toLocaleDateString()}</h3></div><span className={`status status-${o.status.toLowerCase()}`}>{o.status}</span></div><div className="order-lines">{o.items.filter(i => user.role === "admin" || String(i.farmer?._id || i.farmer) === String(user.id || user._id)).map((it,i) => <div key={i}><span>{it.productName} × {it.quantity} {it.unit}</span><strong>{money(it.price * it.quantity)}</strong></div>)}</div><div className="order-total"><span>{o.deliveryAddress}</span><div className="inline-actions">{o.status === "Placed" && <button className="button button-outline button-small" onClick={() => updateStatus(o._id,"Confirmed")}>Confirm</button>}{o.status === "Confirmed" && <button className="button button-outline button-small" onClick={() => updateStatus(o._id,"Packed")}>Mark packed</button>}{o.status === "Packed" && <button className="button button-primary button-small" onClick={() => updateStatus(o._id,"Delivered")}>Mark delivered</button>}</div></div></article>)}</div>}
    </section>
  </div>;
}

function AdminDashboard() {
  const [summary,setSummary] = useState(null); const [users,setUsers] = useState([]); const [error,setError] = useState("");
  useEffect(() => { Promise.all([api.get("/admin/summary"),api.get("/admin/users")]).then(([a,b]) => {setSummary(a.data);setUsers(b.data.users);}).catch(e => setError(e.response?.data?.message || "Could not load admin dashboard.")); }, []);
  return <div className="page-wrap"><div className="page-intro compact"><span className="eyebrow">MARKETPLACE CONTROL</span><h1>Admin <em>overview.</em></h1><p>Monitor the marketplace and its community.</p></div><ErrorMessage>{error}</ErrorMessage>
    {summary && <div className="stats-grid">{[{label:"Registered users",value:summary.users,icon:Users},{label:"Farmers",value:summary.farmers,icon:Sprout},{label:"Products",value:summary.products,icon:Leaf},{label:"Orders",value:summary.orders,icon:ShoppingBasket}].map(s => <div className="stat-card" key={s.label}><s.icon size={22}/><span>{s.label}</span><strong>{s.value}</strong></div>)}</div>}
    <section className="panel"><div className="panel-heading"><div><span className="eyebrow">COMMUNITY</span><h2>Registered accounts</h2></div></div><div className="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Location</th></tr></thead><tbody>{users.map(u => <tr key={u._id}><td>{u.name}</td><td>{u.email}</td><td><span className="status">{u.role}</span></td><td>{u.location || "—"}</td></tr>)}</tbody></table></div></section>
  </div>;
}

export default function App() {
  const cartApi = useCart();
  const add = product => { cartApi.add(product); };
  return <Layout cartCount={cartApi.count}><Routes>
    <Route path="/" element={<Home add={add}/>}/>
    <Route path="/products" element={<Products add={add}/>}/>
    <Route path="/products/:id" element={<ProductDetail add={add}/>}/>
    <Route path="/farmers" element={<Farmers/>}/>
    <Route path="/login" element={<AuthPage mode="login"/>}/>
    <Route path="/register" element={<AuthPage mode="register"/>}/>
    <Route path="/cart" element={<Cart {...cartApi}/>}/>
    <Route path="/orders" element={<ProtectedRoute><Orders/></ProtectedRoute>}/>
    <Route path="/dashboard" element={<ProtectedRoute roles={["farmer","admin"]}><FarmerDashboard/></ProtectedRoute>}/>
    <Route path="/admin" element={<ProtectedRoute roles={["admin"]}><AdminDashboard/></ProtectedRoute>}/>
    <Route path="*" element={<div className="page-wrap empty-state"><h2>Page not found</h2><Link className="button button-primary" to="/">Return home</Link></div>}/>
  </Routes></Layout>;
}
