import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, select: false },
  role: { type: String, enum: ["customer", "farmer", "admin"], default: "customer" },
  phone: { type: String, trim: true, maxlength: 30, default: "" },
  location: { type: String, trim: true, maxlength: 120, default: "" }
}, { timestamps: true });

export default mongoose.model("User", userSchema);
