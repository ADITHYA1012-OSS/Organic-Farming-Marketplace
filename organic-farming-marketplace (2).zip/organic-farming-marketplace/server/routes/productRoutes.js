import { Router } from "express";
import mongoose from "mongoose";
import Product from "../models/Product.js";
import { protect, allowRoles } from "../middleware/authMiddleware.js";

const router = Router();
const validId = id => mongoose.isValidObjectId(id);
const fieldsFrom = body => ({
  name: body.name, description: body.description, category: body.category,
  price: Number(body.price), quantity: Number(body.quantity), unit: body.unit || "kg",
  isOrganic: body.isOrganic !== false, image: body.image || ""
});

router.get("/", async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.category && req.query.category !== "All") filter.category = req.query.category;
    if (req.query.farmer) filter.farmer = req.query.farmer;
    if (req.query.search) filter.$text = { $search: String(req.query.search) };
    const products = await Product.find(filter).populate("farmer", "name location").sort({ createdAt: -1 });
    res.json({ products });
  } catch (err) { next(err); }
});
router.get("/:id", async (req, res, next) => {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid product ID." });
    const product = await Product.findById(req.params.id).populate("farmer", "name location");
    if (!product) return res.status(404).json({ message: "Product not found." });
    res.json({ product });
  } catch (err) { next(err); }
});
router.post("/", protect, allowRoles("farmer", "admin"), async (req, res, next) => {
  try {
    const data = fieldsFrom(req.body);
    if (!data.name?.trim() || !data.category?.trim() || !Number.isFinite(data.price) || data.price < 0 || !Number.isFinite(data.quantity) || data.quantity < 0) {
      return res.status(400).json({ message: "Enter a product name, category, valid price, and valid quantity." });
    }
    const product = await Product.create({ ...data, farmer: req.user._id });
    res.status(201).json({ product });
  } catch (err) { next(err); }
});
router.put("/:id", protect, allowRoles("farmer", "admin"), async (req, res, next) => {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid product ID." });
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: "Product not found." });
    if (req.user.role !== "admin" && String(product.farmer) !== String(req.user._id)) return res.status(403).json({ message: "You can only edit your own products." });
    const data = fieldsFrom(req.body);
    if (!data.name?.trim() || !data.category?.trim() || !Number.isFinite(data.price) || data.price < 0 || !Number.isFinite(data.quantity) || data.quantity < 0) {
      return res.status(400).json({ message: "Enter a product name, category, valid price, and valid quantity." });
    }
    Object.assign(product, data);
    await product.save();
    res.json({ product });
  } catch (err) { next(err); }
});
router.delete("/:id", protect, allowRoles("farmer", "admin"), async (req, res, next) => {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ message: "Invalid product ID." });
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: "Product not found." });
    if (req.user.role !== "admin" && String(product.farmer) !== String(req.user._id)) return res.status(403).json({ message: "You can only delete your own products." });
    await product.deleteOne();
    res.json({ message: "Product deleted." });
  } catch (err) { next(err); }
});
export default router;
